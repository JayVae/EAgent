# NX Open API Notes (verified on NX 10)

Member names often differ from intuition. Verify by reflection before guessing:

    $asm=[Reflection.Assembly]::LoadFrom("$env:UGII_BASE_DIR\UGII\managed\NXOpen.dll")
    $asm.GetTypes() | ? { $_.FullName -eq 'NXOpen.Features.ExtrudeBuilder' } |
      % { $_.GetProperties() | % { $_.Name + ' : ' + $_.PropertyType.Name } }

## Entry point
- Session.GetSession()
- theSession.Parts.Work  (open part)  |  theSession.Parts.NewDisplay(path, Part.Units.Millimeters)
- Last body after a commit: workPart.Bodies.ToArray()(n-1)
  (Feature.GetBodies() does NOT exist on NX10)

## Primitives
| Feature | Builder | Key calls |
|---|---|---|
| Block | `wp.Features.CreateBlockFeatureBuilder(Nothing)` | `.Type = ...OriginAndEdgeLengths` ; `.SetOriginAndLengths(pt,"L","W","H")` |
| Cylinder | `wp.Features.CreateCylinderBuilder(Nothing)` | `.Type = ...AxisDiameterAndHeight` ; `.Diameter.Value` ; `.Height.Value` ; `.Origin` ; `.Direction` |
| Extrude | `wp.Features.CreateExtrudeBuilder(Nothing)` | see below |

Sizes are `Expression` objects: set `.Value` (a double), NOT `.SetFormula`.

## Section from dumb curves (for extrude)
    Dim sec As Section = wp.Sections.CreateSection()
    Dim rule As CurveDumbRule = wp.ScRuleFactory.CreateRuleCurveDumb(curves)
    Dim rules() As SelectionIntentRule = {rule}
    sec.AddToSection(rules, curves(0), Nothing, Nothing, helpPt, Section.Mode.Create, False)

## Extrude limits (GOTCHA)
`Extend.Value` is READ-ONLY. Set the type then the right-hand-side string:
    ext.Limits.StartExtend.TrimType = GeometricUtilities.Extend.ExtendType.Value
    ext.Limits.StartExtend.Value.RightHandSide = "0"
    ext.Limits.EndExtend.Value.RightHandSide   = "2"

## Extrude direction (GOTCHA)
No direction -> NXException "No axis selected".
    ext.Direction = wp.Directions.CreateDirection(New Point3d(0,0,0), New Vector3d(0,0,1), SmartObject.UpdateOption.WithinModeling)

## Curves
- Line: `wp.Curves.CreateLine(New Point3d(x1,y1,0), New Point3d(x2,y2,0))`
- Arc (3-point): `wp.Curves.CreateArc(p1, pOn, p2, alternateSolution, ByRef flipped)`
- Arc (center/angle): `wp.Curves.CreateArc(center, matrix, radius, startAngle, endAngle)`

## Boolean
    Dim b As BooleanBuilder = wp.Features.CreateBooleanBuilder(Nothing)
    b.Operation = Feature.BooleanType.Subtract   ' or Unite / Intersect
    b.Target = targetBody
    b.Tool   = toolBody
    Dim f As Feature = b.CommitFeature()
`Tool` is deprecated (works) - modern path is `ToolBodyCollector`.

## Feature builders seen (not yet wrapped)
- Fillet: `Features.EdgeBlendBuilder` (edges via ScCollector)
- Chamfer: `Features.ChamferBuilder` (`.FirstOffset`, `.SecondOffsetExp`, `.Angle`)
- Pattern: `Features.PatternFeatureBuilder` (`.PatternService`, `.FeatureList`)

## Misc
- Always `CommitFeature()` then `Destroy()` the builder.
- `GetUnloadOption` returns `Session.LibraryUnloadOption.Immediately`.
- `run_journal.exe <journal.vb>` prints "Execution was successful." on success.